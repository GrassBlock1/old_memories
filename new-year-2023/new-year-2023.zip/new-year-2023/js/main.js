
function writeLetter() {
    var from1= document.getElementById("nameFrom").value;
    var to1= document.getElementById("nameTo").value;
    document.getElementById("fromName").innerHTML = from1;
    document.getElementById("toName").innerHTML = to1;
}