# GrassMaterial ！！未完成，趕工中！！
## 介绍
GrassMaterial 是一只基于MDUI设计框架的Typecho主题

A beautiful and simple Material Design Typecho Theme with MDUI.

## 下载
到我们的[开发网站](/)
或者[Release页面](https://github.com/GrassBlock1/GrassMaterial/releases)下载

## 开发者名单
<table>
  <tr>
<td align="center">
  <a href="https://github.com/yuhuan-afk">
  <img src="https://avatars.githubusercontent.com/u/55643232?v=4?s=100" width="100px;" alt=""/>
  <br />
  <sub>
  <b>郭桓桓</b>
  </sub>
  </a>
  <br />
  <a href="https://github.com/TeamMicrol/Balkline/commits?author=yuhuan-afk" title="Code">💻
  </a>
  </td>
  <td align="center"><a href="https://github.com/GrassBlock1"><img src="https://avatars.githubusercontent.com/u/46253950?v=4?s=100" width="100px;" alt=""/><br /><sub><b>草方块</b></sub></a><br /><a href="#design-GrassBlock1" title="Design">🎨</a></td>
  </tr>
</table>

## 特别感谢
感谢Telegram群友[Lapis Apple](https://laple.top)提出设计灵感~

## 支持
[Telegram 群](https://t.me/GrassMaterial)
