<template>
  <div class="container">
    <div id="name-container">
      <img id="avatar" src="./../assets/images/av.png" alt="avatar" />
      <h1>Grassblock</h1>
    </div>
    <div class="title-desc-container">
      <a id="github" href="https://github.com/Grassblock1" target="_blank" rel="noopener noreferrer"
        ><img class="title-font" src="./../assets/images/github.svg" />Front-end Developer</a
      >
      <span>/</span>
      <a id="blog" href="https://blog.imgb.space" target="_blank" rel="noopener noreferrer"
        ><img class="title-font" src="./../assets/images/zeit.svg" />Blogger</a
      >
    </div>
    <div class="article">
      <h2>WHO AM I</h2>
      <p>
      <img src="https://img.shields.io/badge/walker-%2377569-blue?style=flat-square" />
      </p>
      <p>
        I'm <i>Grass Block(草方块)</i> with the ID <i>grass_block</i>. Some other variations:
        <a href="https://twitter.com/Grass_block_cn" target="_blank" rel="noopener noreferrer">@Grass_block_cn</a> /
        <a href="https://t.me/gblock_cn" target="_blank" rel="noopener noreferrer">@gblock_cn</a> /
        <a href="https://github.com/Grassblock1" target="_blank" rel="noopener noreferrer">@Grassblock1</a> / <a href="http://www.coolapk.com/u/1598173" target="_blank" rel="noopener noreferrer">@爱MC的草方块</a>. You may
        know me from GitHub / Telegram / Discord or other places. Yes, those are also me.
      </p>

      <h2>Hobbies</h2>
      <ul>
        <li>
          👨‍💻 Programming (HTML / CSS / Python)
        </li>
        <li>
         🎵 Electronic Music
        </li>
        <li>🎮 Minecraft (Played for 5 years)</li>
        <li>😜 Other Interesting Things</li>
      </ul>

      <h2>Devices</h2>
      <ul>
        <li>⚫ Honor 9x Phone</li>
        <li>🔵 Manjaro Linux Container Running on it...</li>
      </ul>

      <h2>Others About Me （中文）</h2>
      <p>是个蓝孩纸辣（ <del>虽然有时候像小孩子</del></p>
      <p>喜欢在Telegram水群（</p>
      <p>也会时不时地在有熟人的QQ群里水水（</p>
      <p>对某些方面比较了解 但还是想学习新的东西～</p>
      <p>是河北人辣，欢迎老乡来私聊 qwq</p>
      <p>喜欢一些可爱的东西（eg : <a href="https://zh.m.wikipedia.org/zh-tw/貓貓蟲咖波">猫猫虫咖波</a>）</p>
      <p>时不时地会咕咕咕（还是作业太多了</p>
      
      <h2>Contacts</h2>
      <ul>
        <li>
        <b>Telegram : </b>
        <a href="https://t.me/Grass_block">@Grass_block</a><i>(Preferred)</i>
        </li>
        <li>
          <b>Email：</b>
          <a href="mailto:grassblock007@outlook.com">grassblock007#outlook.com</a>
        </li>
      </ul>
    </div>
  </div>
</template>

<style lang="css" scoped>
#name-container {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}

#avatar {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  margin-right: 12px;
}

#copyright:hover {
  border: none;
}

.title-font {
  width: 16px;
  height: 16px;
  margin-right: 4px;
}

.title-desc-container {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  margin: 8px 0;
}

.title-desc-container a {
  display: flex;
  align-items: center;
}

.title-desc-container span {
  margin: 0px 4px;
}

.title-desc-container #github {
  color: #24292e;
}

.title-desc-container #sspai {
  color: #ca2c2a;
}

.title-desc-container #blog {
  color: #0070f3;
}
</style>
