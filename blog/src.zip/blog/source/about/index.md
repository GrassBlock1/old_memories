---
title: 关于站长
date: 2020-04-15 09:48:29
---
你好！我是草方块！一个喜欢编程的人（

是个蓝孩纸辣（ ~~虽然有时候像小孩子~~

喜欢在Telegram 水群（

也会时不时地在有熟人的QQ群里水水（

对某些方面比较了解 但还是想学习新的东西～

是河北人辣，欢迎老乡来私聊 qwq

喜欢一些可爱的东西

喜欢咕果（谷歌）的大多数东西（毕竟很好看

在 Telegram 认识一些大佬

时不时地会咕咕咕（还是作业太多了

咱的群组：
Discord Server
https://discord.gg/c5zf5DJ 服务器

Hangouts
http://hangouts.google.com/group/9SG8YRayqFnLXxds9 咱的小窝

Telegram
[@blockcn_tg](https://t.me/blockcn_tg)

WhatsApp
https://chat.whatsapp.com/LGSqMnukqSp72DrJk5fM7Y

QQ 
![TIM 二维码](https://i.loli.net/2020/04/16/bL9TAPYtiGjQNmI.jpg)

本文是照着 活埋的介绍 写的 可以[去看看>>](https://www.umr2333.com/index.php/about)
