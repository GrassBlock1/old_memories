# oh-my-melon
![GitHub Repo stars](https://img.shields.io/github/stars/GrassBlock1/p0xcheese?style=for-the-badge)

哦我的上帝，这是一个关于某个“退网者”的repo，但是目前呢他又弄了个“新身份”在互联网游荡

就让我们来看看吧

# 减缓更新公告
由于这位及其联盟搬迁到了一个“里群”，作为一个“观察者”，我无法进入这个成员群，故无法正常更新[发言记录](/发盐记录)了。
而且成立的反对组织已经配置好了消息转发，故只会一天备份一次精选的消息
欢迎大家开pr
# 关于此人
网站: https://***who.com

他的学生联盟: https://stublogs.cn/

他的论坛 https://community.stublogs.cn/
