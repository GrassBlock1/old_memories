[Archived For long unmaintenance]

# Grassblock Home

是一个简约美观的个人主页 ～

# 开始使用

前往 [Releses](https://github.com/GrassBlock1/Grassblock.home/releases/) 页面下载打包好后的文件并自行修改，但烦请不要删除指向本项目的部分。
（技术有限，不能开箱即用，抱歉。）

# 支持
如果您喜欢我的项目，可以给一个 Star ，这将是对我的一份动力～
有问题？开个issue罢。

# 协议
MIT License
