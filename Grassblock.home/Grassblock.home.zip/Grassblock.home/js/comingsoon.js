function comingsoon() {
	mdui.snackbar({
		message: 'Coming Soon'
	});
}