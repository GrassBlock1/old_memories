/* 当网页加载完成时，弹出消息 */

window.onload = function () {
  mdui.snackbar({
    message: '欢迎。'
  });
};