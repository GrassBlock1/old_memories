function ctrl() {
	mdui.snackbar({
		message: '按Ctrl+D可以将本页添加到收藏夹～这样就不会迷路了www'
	});
}